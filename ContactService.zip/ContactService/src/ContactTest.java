
public class ContactTest {

}
